macroScript ThemesManager category:"MYARTSBOX" tooltip:"3ds Max Themes Manager"
(
    filein (getFilenamePath (getSourceFileName()) + "mab.ThemesManager.ms")
)
